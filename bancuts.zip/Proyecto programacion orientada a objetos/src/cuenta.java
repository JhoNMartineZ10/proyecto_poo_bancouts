
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author USUARIO
 */
public class cuenta implements Serializable {

    private int idcuenta;
    private double saldo;
    private String tipocuenta;

    public int getIdcuenta() {
        return idcuenta;
    }

    public void setIdcuenta(int idcuenta) {
        this.idcuenta = idcuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getTipocuenta() {
        return tipocuenta;
    }

    public void setTipocuenta(String tipocuenta) {
        this.tipocuenta = tipocuenta;
    }

    public cuenta(int idcuenta, double saldo, String tipocuenta) {
        this.idcuenta = idcuenta;
        this.saldo = saldo;
        this.tipocuenta = tipocuenta;
    }
    
    @Override
	public String toString() {
		return "usuario [" + idcuenta + ", " + saldo + ", " + tipocuenta + "]";
	}

   

}
