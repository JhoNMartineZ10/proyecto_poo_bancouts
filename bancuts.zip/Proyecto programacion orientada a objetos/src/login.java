
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.scene.paint.Color.color;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author USUARIO
 */
public class login extends javax.swing.JFrame {

    
    public login() {
        initComponents();
        setTitle(" BancUTS   login"); // Establece el título de la ventana
        setSize(1400, 800); // Establece el tamaño de la ventana (ancho x alto)
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
        setResizable(false); // Hace que la ventana no sea redimensionable
        setDefaultCloseOperation(login.EXIT_ON_CLOSE); // Cierra la aplicación al cerrar la
        setLayout(new BorderLayout()); // Establece el layout de la ventana a BorderLayout
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/Banc.png")).getImage());
        
       

        lusuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lcontraseña.requestFocus(); // Mover el foco al siguiente campo
            }
        });

// Agregar ActionListener para pasar el foco del campo2 al botón campo3
        lcontraseña.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                entrar.requestFocus(); // Mover el foco al botón
                entrar.doClick(); // Simula el clic en el botón
            }
        });

// Agregar ActionListener al botón para que realice la acción deseada
        entrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción del botón (puedes personalizarlo según tu lógica)
            
            }
        });

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        lusuario = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        entrar = new javax.swing.JButton();
        lcontraseña = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        cusuario = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Banc.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 520, 370));

        lusuario.setFont(new java.awt.Font("Arial Black", 1, 13)); // NOI18N
        lusuario.setBorder(null);
        lusuario.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        lusuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lusuarioActionPerformed(evt);
            }
        });
        getContentPane().add(lusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 380, 290, 50));

        jLabel4.setFont(new java.awt.Font("Castellar", 0, 48)); // NOI18N
        jLabel4.setText("Bienvenido al banco UTS ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 50, 780, 80));

        entrar.setBackground(new java.awt.Color(102, 255, 204));
        entrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Diseño_sin_título__5_-removebg-preview.png"))); // NOI18N
        entrar.setToolTipText("");
        entrar.setBorder(null);
        entrar.setBorderPainted(false);
        entrar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entrarActionPerformed(evt);
            }
        });
        getContentPane().add(entrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 590, 140, 50));

        lcontraseña.setFont(new java.awt.Font("Arial Black", 0, 13)); // NOI18N
        lcontraseña.setBorder(null);
        getContentPane().add(lcontraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 470, 270, 40));

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 1, 13)); // NOI18N
        jLabel3.setText(" Si no tienes usauario puedes crear uno AQÚI ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 540, 250, 30));

        cusuario.setBackground(new java.awt.Color(102, 255, 255));
        cusuario.setFont(new java.awt.Font("Arial Narrow", 0, 13)); // NOI18N
        cusuario.setText("Crear Usuario ");
        cusuario.setBorder(null);
        cusuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cusuarioActionPerformed(evt);
            }
        });
        getContentPane().add(cusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 540, 110, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/login1.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 190, 580, 550));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/30.-UTS.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 0, 220, 140));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 1390, 780));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lusuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lusuarioActionPerformed

    private void entrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entrarActionPerformed
        String usuariosIngresado = lusuario.getText();
        String passwordIngresada = lcontraseña.getText();

        if (usuariosIngresado.isEmpty() || passwordIngresada.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Algún campo está vacío");
        } else {
            // Llamar al método validarUsuario para verificar credenciales
            if (iniciar.validarUsuario(usuariosIngresado, passwordIngresada)) {
                // Usuario y contraseña válidos: abrir nueva ventana
                inicio pc = new inicio(); // Clase del siguiente JFrame
                pc.setVisible(true);
                this.dispose(); // Cierra el JFrame actual
            } else {
                JOptionPane.showMessageDialog(null, "Su usuario o contraseña es incorrecta");
            }
        }
    }//GEN-LAST:event_entrarActionPerformed

    private void cusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cusuarioActionPerformed
        cusuario.setBackground(Color.green);

        crear_cuenta pc = new crear_cuenta();
        pc.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_cusuarioActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cusuario;
    private javax.swing.JButton entrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPasswordField lcontraseña;
    private javax.swing.JTextField lusuario;
    // End of variables declaration//GEN-END:variables
}
