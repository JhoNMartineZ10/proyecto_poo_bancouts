
import java.io.Serializable;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USUARIO
 */
public class evento implements Serializable {
    private int idevento;
    private String descripcionevento;
    private double recompensa;
     private Date fechaevento;

    public double getRecompesa() {
        return recompensa;
    }

    public void setRecompesa(double recompesa) {
        this.recompensa = recompesa;
    }
   
    public int getIdevento() {
        return idevento;
    }

    public void setIdevento(int idevento) {
        this.idevento = idevento;
    }

    public String getDescripcionevento() {
        return descripcionevento;
    }

    public void setDescripcionevento(String descripcionevento) {
        this.descripcionevento = descripcionevento;
    }

    public Date getFechaevento() {
        return fechaevento;
    }

    public void setFechaevento(Date fechaevento) {
        this.fechaevento = fechaevento;
    }
    
     public evento(int idevento, String descripcionevento, double recompensa, Date fechaevento) {
        this.idevento = idevento;
        this.descripcionevento= descripcionevento;
        this.recompensa= recompensa;
        this.fechaevento = fechaevento;
     }

    
     
    
}
