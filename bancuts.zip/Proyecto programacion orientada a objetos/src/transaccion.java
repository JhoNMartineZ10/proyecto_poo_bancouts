
import java.io.Serializable;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USUARIO
 */
public class transaccion implements Serializable {
    private int idtransaccion;
    private String tipotransaccion;
    private double monto;
    private Date fechatran;

    public int getIdtransaccion() {
        return idtransaccion;
    }

    public void setIdtransaccion(int idtransaccion) {
        this.idtransaccion = idtransaccion;
    }

    public String getTipotransaccion() {
        return tipotransaccion;
    }

    public void setTipotransaccion(String tipotransaccion) {
        this.tipotransaccion = tipotransaccion;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Date getFechatran() {
        return fechatran;
    }

    public void setFechatran(Date fechatran) {
        this.fechatran = fechatran;
    }
    
     public transaccion( int idtransaccion, String tipotransaccion, double monto, Date fechatran) {
        this.idtransaccion = idtransaccion;
        this.tipotransaccion= tipotransaccion;
        this.monto = monto;
        this.fechatran = fechatran;
     }

    
     
     
}
