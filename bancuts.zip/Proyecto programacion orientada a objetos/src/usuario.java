
import java.io.Serializable;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USUARIO
 */
public class usuario implements Serializable {
    private int idusuario;
    private String nombre;
    private String apellidos;
    private int cedula;
    private String ciudad;
    private String correo;
    private String iusuario;
    private String contraseña;
   
   
   

    
      public usuario(int idusuario, String nombre, String apellidos, int cedula, String ciudad, String correo,
              String iusuario, String contraseña) {
		this.idusuario = idusuario;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.cedula = cedula;
                this.ciudad  =  ciudad;
                this.  correo= correo ;
                this.iusuario  = iusuario ;
                this. contraseña =  contraseña;
                System.out.println(idusuario);
                        System.out.println("p "+nombre);
                        System.out.println("p "+apellidos);
                        System.out.println("p "+cedula);
                        System.out.println("p "+ciudad);
                        System.out.println("p "+correo);
                        System.out.println("p "+iusuario);
                        System.out.println("p "+contraseña);
	}
    
    
    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsuario() {
        return iusuario;
    }

    public void setUsuario(String usuario) {
        this.iusuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    @Override
	public String toString() {
		return "usuario [" + idusuario + ", " + nombre + ", " + apellidos + ", "
		+ cedula + ", " +ciudad + ", " +correo+ ", " +iusuario+ ", " +contraseña+"]";
	}
    
    
}

