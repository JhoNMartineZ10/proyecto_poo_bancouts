
import java.awt.BorderLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import static java.lang.Math.random;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class iniciar {

//--------------------------------------------------------------------------------------------------------------------------------
    public static ArrayList<usuario> usuarios = new ArrayList<usuario>();

    public static usuario usuario;

    public static String datosusuario = "usuarios.dat";
//--------------------------------------------------------------------------------------------------------------------------------
    public static ArrayList<cuenta> cuentas = new ArrayList<cuenta>();

    public static cuenta cuenta;

    public static String datoscuenta = "cuentas.dat";
//--------------------------------------------------------------------------------------------------------------------------------
    public static ArrayList<evento> eventos = new ArrayList<evento>();

    public static evento evento;

    public static String datosevento = "eventos.dat";
//--------------------------------------------------------------------------------------------------------------------------------
    public static ArrayList<transaccion> transacciones = new ArrayList<transaccion>();

    public static transaccion transaccion;

    public static String datostransaccion = "transacciones.dat";
//--------------------------------------------------------------------------------------------------------------------------------
    private static Random random = new Random(); // Para generar datos aleatorios
    LocalDate fechaMaxima = hoy.plusMonths(3); // Fecha máxima (3 meses a partir de hoy)

    private static int idEventoCounter = 0;

    public static void main(String[] args) {
        usuarios = cargarusuarios();
        cuentas = cargarcuenta();
        eventos = cargarevento();
        transacciones = cargartransaccion();

        // Definir tipos de eventos y ubicaciones
        String[] tiposEventos = {
            "evento deportivo en la plazoleta UTS",
            "evento de baile en el salón 304C UTS",
            "concierto de música en el auditorio UTS",
            "charla sobre tecnología en el salón 101 UTS",
            "taller de arte en el salón 202 UTS",
            "feria de ciencias en la plazoleta UTS",
            "competencia de robótica en el salón 303 UTS",
            "exposición de fotografía en el pasillo UTS",
            "evento cultural en el salón 105 UTS",
            "seminario de salud en el salón 204 UTS",
            "jornada de deportes extremos en la cancha UTS",
            "muestra de cine en el auditorio UTS",
            "taller de cocina en el salón 201 UTS",
            "evento de networking en el salón 102 UTS",
            "charla motivacional en el salón 305 UTS",
            "competencia de matemáticas en el salón 106 UTS",
            "exposición de arte en la galería UTS",
            "conferencia sobre medio ambiente en el salón 204 UTS",
            "festival de música en la plazoleta UTS",
            "taller de programación en el salón 302 UTS"
        };

        LocalDate hoy = LocalDate.now(); // Fecha actual
        LocalDate fechaMaxima = hoy.plusMonths(3); // Fecha máxima (3 meses a partir de hoy)
        for (int i = 0; i < 20; i++) {
            idEventoCounter++; // Incrementar el ID del evento
            int idevento = idEventoCounter; // Asignar el nuevo ID
            String descripcion = tiposEventos[random.nextInt(tiposEventos.length)];
            double recompen = (random.nextInt(100) + 1); // Recompensa aleatoria entre 1 y 100
            // Generar una fecha aleatoria entre hoy y la fecha máxima
            long daysBetween = fechaMaxima.toEpochDay() - hoy.toEpochDay(); // Corregido
            long randomDays = random.nextInt((int) (daysBetween + 1)); // Días aleatorios
            LocalDate fechaevento = hoy.plusDays(randomDays); // Fecha aleatoria

            // Convertir LocalDate a Date
            Date fecha = java.sql.Date.valueOf(fechaevento); // Conversión a Date
            crearevento(descripcion, recompen, fecha);
           /* evento = new evento(idevento, descripcion, recompen, fecha);
            eventos.add(evento);*/

        }

        login main = new login(); // Crea una nueva instancia de la clase ventana
        main.setVisible(true); // Hace que la ventana sea visible

    }

//---------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------
    public static boolean validarUsuario(String usuarioIngresado, String contrasenaIngresada) {
        JOptionPane.showMessageDialog(null, listarusuarios());;
        JOptionPane.showMessageDialog(null, listarcuenta());;
        JOptionPane.showMessageDialog(null, listarevento());;
        // Verifica que usuarios no sea null
        if (usuarios == null || usuarios.isEmpty()) {
            System.out.println("La lista de usuarios es null o está vacía.");
            return false;
        }

        for (usuario usuario : usuarios) {
            System.out.println("Verificando usuario: " + usuario.getUsuario());
            if (usuario.getUsuario() == null) {
                System.out.println("El usuario es null.");
                continue;
            }
            if (usuario.getContraseña() == null) {
                System.out.println("La contraseña es null.");
                continue;
            }

            if (usuario.getUsuario().equals(usuarioIngresado)) {
                if (usuario.getContraseña().equals(contrasenaIngresada)) {
                    return true;
                }
            }
        }

        return false;  // Si no se encuentra el usuario
    }

    public static void modificarusuario() {

        String texto = listarusuarios();
        int indice = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea modificar:\n" + texto));
        if (indice > 0 && indice <= usuarios.size()) {
            usuario usuario = usuarios.get(indice - 1);
            int idusuario = Integer.parseInt(JOptionPane.showInputDialog("por favor escriba la cantidad del producto. "));
            String nombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre del producto (actual: " + usuario.getNombre() + ")", usuario.getNombre());
            String apellidos = JOptionPane.showInputDialog("por favor escriba el nombre del producto. ");
            int cedula = Integer.parseInt(JOptionPane.showInputDialog("por favor escriba la cantidad del producto. "));
            String ciudad = JOptionPane.showInputDialog("por favor escriba el nombre del producto. ");
            String correo = JOptionPane.showInputDialog("por favor escriba el nombre del producto. ");
            String iusuario = JOptionPane.showInputDialog("por favor escriba el nombre del producto. ");
            String contraseña = JOptionPane.showInputDialog("por favor escriba el nombre del producto. ");
            usuario.setIdusuario(idusuario);
            usuario.setNombre(nombre);
            usuario.setApellidos(apellidos);
            usuario.setCedula(cedula);
            usuario.setCiudad(ciudad);
            usuario.setCorreo(correo);
            usuario.setUsuario(iusuario);
            usuario.setContraseña(contraseña);

            JOptionPane.showMessageDialog(null, "Producto modificado con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "Índice inválido.");
        }
    }

    public static void eliminarusuario() {
        String textou = listarusuarios();
        int indiceEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea eliminar:\n " + textou));

        // Validar que el índice esté dentro de los límites de la lista
        if (indiceEliminar > 0 && indiceEliminar <= usuarios.size()) {
            // Restar 1 porque los índices comienzan en 0
            usuarios.remove(indiceEliminar - 1);
            JOptionPane.showMessageDialog(null, "usuario eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "Número de usuario no válido.");
        }
    }

    public static String listarusuarios() {
        String texto = "";
        for (usuario usuario : usuarios) {
            texto += "\n" + " [ " + (usuarios.indexOf(usuario) + 1) + " ] " + usuario;
        }
        return texto;
    }
    private static int idUsuarioCounter = 0; // Contador estático para el ID del usuario
    private static double s = 0;
    private static String tc = "Ahorros";

    public static void crearusuario(String nomb, String ape, int ced, String ciu, String corr, String usu, String pas) {
        idUsuarioCounter++; // Incrementar el ID del usuario
        int idusuario = idUsuarioCounter; // Asignar el nuevo ID
        int idcuenta = idUsuarioCounter; // Asignar el nuevo ID
        Double saldo = s;
        String tipocuenta = tc;
        String nombre;
        String apellidos;
        int cedula;
        String ciudad;
        String correo;
        String iusuario;
        String contraseña;
        nombre = nomb;
        apellidos = ape;
        cedula = ced;
        ciudad = ciu;
        correo = corr;
        iusuario = usu;
        contraseña = pas;
        System.out.println(idusuario);
        System.out.println(idcuenta);
        System.out.println(nombre);
        System.out.println(apellidos);
        System.out.println(cedula);
        System.out.println(ciudad);
        System.out.println(correo);
        System.out.println(iusuario);
        System.out.println(contraseña);

        usuario = new usuario(idusuario, nombre, apellidos, cedula, ciudad, correo, iusuario, contraseña);
        usuarios.add(usuario);
        cuenta = new cuenta(idcuenta, saldo, tipocuenta);
        cuentas.add(cuenta);

    }

    public static ArrayList<usuario> cargarusuarios() {
        ArrayList<usuario> usuarios = new ArrayList<usuario>();
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(datosusuario));
            Object aux = ois.readObject();
            while (aux != null) {
                System.out.println("se cargoo los datos usuario");
                if (aux instanceof usuario) {
                    usuario.add((usuario) aux);
                }
                aux = ois.readObject();

            }
            ois.close();
        } catch (FileNotFoundException e) {
            try {
                System.out.println("se va a crear nuevo archivo usuario ");
                File archivo = new File(datosusuario);
                archivo.createNewFile();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } catch (Exception e) {

        }
        return usuarios;
    }

    /**
     * Recibe un listado de productos y guarda en un archivo .dat
     *
     * @param usuarios
     */
    public static void guardausuario() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(datosusuario));
            for (usuario usuario : usuarios) {
                oos.writeObject(usuario);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//--------------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------------

    public static void modificarcuenta() {
        String texto = listarcuenta();
        int indice = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea modificar:\n" + texto));
        if (indice > 0 && indice <= cuentas.size()) {
            cuenta cuenta = cuentas.get(indice - 1);
            int idcuenta = Integer.parseInt(JOptionPane.showInputDialog("por favor escriba la cantidad del producto. "));
            double saldo = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el nuevo nombre del producto (actual: " + cuenta.getSaldo() + ")", cuenta.getSaldo()));
            String tipocuenta = JOptionPane.showInputDialog("por favor escriba el nombre del producto. ");
            cuenta.setIdcuenta(idcuenta);
            cuenta.setSaldo(saldo);
            cuenta.setTipocuenta(tipocuenta);

            JOptionPane.showMessageDialog(null, "Producto modificado con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "Índice inválido.");
        }
    }

    public static void eliminarcuenta() {
        String textou = listarcuenta();
        int indiceEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea eliminar:\n " + textou));

        // Validar que el índice esté dentro de los límites de la lista
        if (indiceEliminar > 0 && indiceEliminar <= cuentas.size()) {
            // Restar 1 porque los índices comienzan en 0
            cuentas.remove(indiceEliminar - 1);
            JOptionPane.showMessageDialog(null, "Producto eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "Número de producto no válido.");
        }
    }

    public static String listarcuenta() {
        String texto = "";
        for (cuenta cuenta : cuentas) {
            texto += "\n" + " [ " + (cuentas.indexOf(cuenta) + 1) + " ] " + cuenta;
        }
        return texto;
    }

    public static ArrayList<cuenta> cargarcuenta() {
        ArrayList<cuenta> cuentas = new ArrayList<cuenta>();
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(datoscuenta));
            Object aux = ois.readObject();
            while (aux != null) {
                System.out.println("se cargoo los datos cuenta");
                if (aux instanceof cuenta) {
                    cuenta.add((cuenta) aux);
                }
                aux = ois.readObject();

            }
            ois.close();
        } catch (FileNotFoundException e) {
            try {
                System.out.println("se va a crear nuevo archivo cuenta ");
                File archivo = new File(datoscuenta);
                archivo.createNewFile();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } catch (Exception e) {

        }
        return cuentas;
    }

    /**
     * Recibe un listado de productos y guarda en un archivo .dat
     *
     * @param cuentas
     */
    public static void guardacuenta() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(datoscuenta));
            for (cuenta cuenta : cuentas) {
                oos.writeObject(cuenta);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//---------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------

    public static void crearevento(String descripcio, double recompen, Date fecha) {
        idEventoCounter++; // Incrementar el ID del evento
        int idevento = idEventoCounter; // Asignar el nuevo ID
        String descripcion;
        double recompensa;
        Date fechaevento;
        descripcion = descripcio;
        recompensa = recompen;
        fechaevento = fecha;

        // Crear el nuevo evento
        evento = new evento(idevento, descripcion, recompensa, fechaevento);
        eventos.add(evento); // Agregar el evento a la lista

        // Mostrar información del evento creado
        System.out.println("Evento creado: " + evento);
    }
    public static void modificarevento() throws ParseException {
        String texto = listarevento();
        int indice = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea modificar:\n" + texto));
        if (indice > 0 && indice <= eventos.size()) {
            evento evento = eventos.get(indice - 1);
            int idevento = Integer.parseInt(JOptionPane.showInputDialog("por favor escriba la cantidad del producto. "));
            String descripcionevento = JOptionPane.showInputDialog("Ingrese el nuevo nombre del producto (actual: " + cuenta.getSaldo() + ")", cuenta.getSaldo());
            String input = JOptionPane.showInputDialog("Por favor, escriba la fecha en formato dd/MM/yyyy:");
            // Definir el formato de la fecha
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            formato.setLenient(false); // Para que no acepte fechas inválidas
            // Parsear la cadena a un objeto Date
            Date fechaevento = formato.parse(input);

            evento.setIdevento(idevento);
            evento.setDescripcionevento(descripcionevento);
            evento.setFechaevento(fechaevento);

            JOptionPane.showMessageDialog(null, "Producto modificado con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "Índice inválido.");
        }
    }

    public static void eliminarevento() {
        String textou = listarevento();
        int indiceEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea eliminar:\n " + textou));

        // Validar que el índice esté dentro de los límites de la lista
        if (indiceEliminar > 0 && indiceEliminar <= eventos.size()) {
            // Restar 1 porque los índices comienzan en 0
            eventos.remove(indiceEliminar - 1);
            JOptionPane.showMessageDialog(null, "evento eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "Número de evento no válido.");
        }
    }

    public static String listarevento() {
        String texto = "";
        for (evento evento : eventos) {
            texto += "\n" + " [ " + (eventos.indexOf(evento) + 1) + " ] " + evento;
        }
        return texto;
    }

    public static ArrayList<evento> cargarevento() {
        ArrayList<evento> eventos = new ArrayList<evento>();
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(datosevento));
            Object aux = ois.readObject();
            while (aux != null) {
                System.out.println("se cargoo los datos evento");
                if (aux instanceof evento) {
                    evento.add((evento) aux);
                }
                aux = ois.readObject();

            }
            ois.close();
        } catch (FileNotFoundException e) {
            try {
                System.out.println("se va a crear nuevo archivo evento");
                File archivo = new File(datosevento);
                archivo.createNewFile();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } catch (Exception e) {

        }
        return eventos;
    }

    /**
     * Recibe un listado de productos y guarda en un archivo .dat
     *
     * @param eventos
     */
    public static void guardaevento() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(datosevento));
            for (evento evento : eventos) {
                oos.writeObject(evento);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//---------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------
    public static void modificartransaccion() throws ParseException {
        String texto = listartransaccion();
        int indice = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea modificar:\n" + texto));
        if (indice > 0 && indice <= transacciones.size()) {
            transaccion transaccion = transacciones.get(indice - 1);
            int idtransaccion = Integer.parseInt(JOptionPane.showInputDialog("por favor escriba la cantidad del producto. "));
            String tipotransaccion = JOptionPane.showInputDialog("Ingrese el nuevo nombre del producto (actual: " + transaccion.getTipotransaccion() + ")", transaccion.getTipotransaccion());
            Double monto = Double.parseDouble(JOptionPane.showInputDialog("por favor escriba la cantidad del producto. "));
            String input = JOptionPane.showInputDialog("Por favor, escriba la fecha en formato dd/MM/yyyy:");
            // Definir el formato de la fecha
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            formato.setLenient(false); // Para que no acepte fechas inválidas
            // Parsear la cadena a un objeto Date
            Date fechatran = formato.parse(input);

            transaccion.setIdtransaccion(idtransaccion);
            transaccion.setTipotransaccion(tipotransaccion);
            transaccion.setMonto(monto);
            transaccion.setFechatran(fechatran);

            JOptionPane.showMessageDialog(null, "Producto modificado con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "Índice inválido.");
        }
    }

    public static void eliminartransaccion() {
        String textou = listartransaccion();
        int indiceEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número del producto que desea eliminar:\n " + textou));

        // Validar que el índice esté dentro de los límites de la lista
        if (indiceEliminar > 0 && indiceEliminar <= transacciones.size()) {
            // Restar 1 porque los índices comienzan en 0
            transacciones.remove(indiceEliminar - 1);
            JOptionPane.showMessageDialog(null, "evento eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "Número de evento no válido.");
        }
    }

    public static String listartransaccion() {
        String texto = "";
        for (transaccion transaccion : transacciones) {
            texto += "\n" + " [ " + (transacciones.indexOf(transaccion) + 1) + " ] " + transaccion;
        }
        return texto;
    }

    public static ArrayList<transaccion> cargartransaccion() {
        ArrayList<transaccion> transacciones = new ArrayList<transaccion>();
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(datostransaccion));
            Object aux = ois.readObject();
            while (aux != null) {
                System.out.println("se cargoo los datos transaccion");
                if (aux instanceof transaccion) {
                    transaccion.add((transaccion) aux);
                }
                aux = ois.readObject();

            }
            ois.close();
        } catch (FileNotFoundException e) {
            try {
                System.out.println("se va a crear nuevo archivo transaccion ");
                File archivo = new File(datostransaccion);
                archivo.createNewFile();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } catch (Exception e) {

        }
        return transacciones;
    }

    /**
     * Recibe un listado de productos y guarda en un archivo .dat
     *
     * @param transacciones
     */
    public static void guardatransaccion() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(datostransaccion));
            for (transaccion transaccion : transacciones) {
                oos.writeObject(transaccion);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
